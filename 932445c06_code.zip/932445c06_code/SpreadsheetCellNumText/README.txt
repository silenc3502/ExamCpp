Three source files in this directory include a main() function. Your project
should include SpreadsheetCell.cpp and one of SpreadsheetCellTest.cpp,
SpreadsheetCellHeap.cpp, SpreadsheetCellHeapAlternate.cpp, or
SpreadsheetCellHeapSmartPointer.cpp


