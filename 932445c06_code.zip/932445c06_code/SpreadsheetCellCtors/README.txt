Three source files in this directory include a main() function. Your project
should include SpreadsheetCell.cpp and one of SpreadsheetCellTest.cpp,
SpreadsheetCellTestDefault.cpp, or SpreadsheetCellArrayNoDefault.cpp.
Note that only the SpreadsheetCellTest.cpp actually compiles.


