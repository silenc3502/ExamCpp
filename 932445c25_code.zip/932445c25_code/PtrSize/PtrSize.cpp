#include <iostream>

using namespace std;

int main()
{
	int *ptr;
	cout << "ptr size is " << sizeof(ptr) << " bytes" << endl;

	return 0;
}
