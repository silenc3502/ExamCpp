The program MixingC.cpp will not compile in C++, but will compile in C.
