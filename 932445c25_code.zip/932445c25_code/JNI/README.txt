For information on how to compile and use the JNI example, please see Chapter 25.
