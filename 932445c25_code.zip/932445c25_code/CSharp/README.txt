For information on how to compile and use the C# example, please see Chapter 25.
