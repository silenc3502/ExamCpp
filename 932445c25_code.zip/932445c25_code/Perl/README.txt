To run this example, compile encryptString.cpp into a program named encryptString and execute the perl script with:

> perl processLog.pl

