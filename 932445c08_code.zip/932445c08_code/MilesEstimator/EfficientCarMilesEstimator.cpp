#include "EfficientCarMilesEstimator.h"

int EfficientCarMilesEstimator::getMilesPerGallon()
{
  return 35;
}
