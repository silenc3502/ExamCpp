// Cherry.h

#include <iostream>

using namespace std;

class Cherry {

 public:
  Cherry() {};

  virtual void printType() { cout << "I am a Cherry" << endl; }

};
