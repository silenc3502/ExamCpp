Compile each of the source files in this directory separately.


Notes:
CathingPolymorphicallyIncorrect.cpp may generate warnings when compiled.
