#include <iostream>
#include <string>

using namespace std;

int main()
{
	int i = 7;
	cout << i << endl;

	char ch = 'a';
	cout << ch << endl;

	string myString = "Marni is adorable.";
	cout << myString << endl;


	int j = 11;
	cout << "On a scale of 1 to cute, Marni ranks " << j << "!" << endl;


	cout << "Line 1" << endl << "Line 2" << endl << "Line 3" << endl;

	return 0;
}
