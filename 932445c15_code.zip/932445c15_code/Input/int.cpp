#include <iostream>
#include <string>

using namespace std;

int main()
{
	int userInput;
	cin >> userInput;
	cout << "User input was " << userInput << endl;

	return 0;
}
