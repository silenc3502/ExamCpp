#include <iostream>

using namespace std;

int main()
{
	cout << "abc";
	cout.flush();    // abc is written to the console.
	cout << "def";
	cout << endl;    // def is written to the console.

	return 0;
}
