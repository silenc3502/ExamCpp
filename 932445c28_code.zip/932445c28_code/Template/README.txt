To compile, do not include SimpleTemplate.cpp in the project.
