Compile AnotherFile.cpp and FirstFile.cpp together.
Compile order.cpp alone.
Compile StaticsInFunctions.cpp alone.
Notes:
	AnotherFile.cpp and FirstFile.cpp will fail at the link stage.
