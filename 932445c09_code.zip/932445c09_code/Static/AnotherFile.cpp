// AnotherFile.cpp

#include <iostream>
using namespace std;

//void f();
static void f();

void f()
{
  cout << "f\n";
}
