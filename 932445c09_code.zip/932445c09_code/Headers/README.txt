These header files are just examples. There is nothing to compile.
