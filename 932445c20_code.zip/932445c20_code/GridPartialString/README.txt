Compile each of GridTest.cpp and GridTestString.cpp separately.

Older versions of Microsoft Visual C++ might not be able to
compile GridTestString.cpp because they don't fully support
that feature. However, recent versions compile it without problems.
