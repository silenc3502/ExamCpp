// TestLoggerAdapter.cpp

#include "LoggerAdapter.h"

int main() 
{
	NewLoggerAdapter logger;
	logger.log("Testing the logger.");

	return 0;
} 
