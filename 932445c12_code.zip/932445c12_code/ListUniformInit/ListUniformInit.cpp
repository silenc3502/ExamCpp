#include <list>
#include <string>

using namespace std;

int main()
{
	list<string> lst = {"String 1", "String 2", "String 3"};

	return 0;
}
